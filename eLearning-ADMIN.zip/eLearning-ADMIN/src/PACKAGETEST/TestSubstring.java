/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PACKAGETEST;

/**
 *
 * @author ACER
 */
public class TestSubstring {
    public static void main(String[] args) {
        String y ="2023-12-09";
        System.out.println("bulan " +y.substring(5, 7));
        System.out.println("Tanggal " +y.substring(8, 10));
    }
}
