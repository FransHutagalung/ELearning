
package QUIZCREATED;


public interface DBQUIZ {
    
    void create();
    void create(String password);
}
