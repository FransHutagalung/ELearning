package QUIZCREATED;


public interface QUIZFILLDB {
    
    void addDB(int batas);
    void setLength();
    void getInfoQuestion();
    void setPicture();
    void getPicture();
}
