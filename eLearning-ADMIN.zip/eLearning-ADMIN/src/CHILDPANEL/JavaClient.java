/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CHILDPANEL;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class JavaClient {
    public static void main(String[] args) {
        try {
            // Specify the URL of your Node.js server
            String nodeJsUrl = "mata pelajaran apa yang kira kira masuk untuk ujian snbt tahun 2024 ini ?";

            // Send HTTP GET request to the Node.js server


       

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   
}
